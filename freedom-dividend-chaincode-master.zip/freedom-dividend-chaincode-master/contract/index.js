'use strict';

const FreedomDividendContract = require('./lib/freedomDividendContract.js');

module.exports.FreedomDividendContract = FreedomDividendContract;
module.exports.contracts = [ FreedomDividendContract ];
